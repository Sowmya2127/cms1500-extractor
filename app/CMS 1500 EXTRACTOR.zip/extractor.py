import json
import os
from groq import Groq
from dotenv import load_dotenv

load_dotenv(dotenv_path=os.path.join(os.path.dirname(__file__), '..', '.env'))

CMS_FIELDS = """
Box 1   - insurance_type (Medicare/Medicaid/Tricare/ChampVA/Group Health Plan/FECA/Other)
Box 1a  - insured_id_number
Box 2   - patient_name
Box 3   - patient_dob, patient_sex
Box 4   - insured_name
Box 5   - patient_address, patient_city, patient_state, patient_zip, patient_phone
Box 6   - patient_relationship_to_insured (Self/Spouse/Child/Other)
Box 7   - insured_address, insured_city, insured_state, insured_zip, insured_phone
Box 8   - reserved_for_nucc_use
Box 9   - other_insured_name
Box 9a  - other_insured_policy_or_group_number
Box 9b  - reserved_for_nucc_use_9b
Box 9c  - reserved_for_nucc_use_9c
Box 9d  - other_insurance_plan_name
Box 10a - condition_related_to_employment (yes/no)
Box 10b - condition_related_to_auto_accident (yes/no), auto_accident_state
Box 10c - condition_related_to_other_accident (yes/no)
Box 10d - claim_codes
Box 11  - insured_policy_group_or_feca_number
Box 11a - insured_dob, insured_sex
Box 11b - other_claim_id
Box 11c - insurance_plan_name
Box 11d - another_health_benefit_plan (yes/no)
Box 12  - patient_signature, patient_signature_date
Box 13  - insured_signature
Box 14  - illness_injury_pregnancy_date, date_qualifier
Box 15  - other_date, other_date_qualifier
Box 16  - unable_to_work_from_date, unable_to_work_to_date
Box 17  - referring_provider_name, referring_provider_qualifier
Box 17a - other_id_number
Box 17b - referring_provider_npi
Box 18  - hospitalization_from_date, hospitalization_to_date
Box 19  - additional_claim_information
Box 20  - outside_lab (yes/no), outside_lab_charges
Box 21  - diagnosis_codes (list A through L), icd_indicator
Box 22  - resubmission_code, original_ref_number
Box 23  - prior_authorization_number
Box 24  - service_lines (list of objects each containing:
            date_of_service_from, date_of_service_to,
            place_of_service, emg,
            procedure_code, modifier,
            diagnosis_pointer, charges,
            days_or_units, epsdt_family_plan,
            rendering_provider_id, rendering_provider_npi)
Box 25  - federal_tax_id, tax_id_type (SSN/EIN)
Box 26  - patient_account_number
Box 27  - accept_assignment (yes/no)
Box 28  - total_charge
Box 29  - amount_paid
Box 30  - reserved_for_nucc_use_30
Box 31  - signature_of_physician, signature_date
Box 32  - service_facility_name, service_facility_address, service_facility_city_state_zip
Box 32a - service_facility_npi
Box 32b - service_facility_other_id
Box 33  - billing_provider_phone, billing_provider_name, billing_provider_address, billing_provider_city_state_zip
Box 33a - billing_provider_npi
Box 33b - billing_provider_other_id
"""

def extract_fields(ocr_text: str) -> dict:
    client = Groq(api_key=os.getenv("GROQ_API_KEY"))

    prompt = f"""
    You are a medical billing expert specializing in CMS 1500 health insurance claim forms.
    Below is OCR text extracted from a CMS 1500 form.
    
    Extract ALL fields listed below and return ONLY a valid JSON object.
    Rules:
    - Set missing or unreadable fields to null
    - For Box 24 service_lines, return a list of objects for each row
    - For diagnosis_codes return a list
    - Do not include any explanation or markdown
    - Return only the JSON object

    Fields:
    {CMS_FIELDS}

    OCR Text:
    {ocr_text}
    """

    response = client.chat.completions.create(
        model="llama-3.3-70b-versatile",
        messages=[{"role": "user", "content": prompt}],
        temperature=0,
        max_tokens=3000
    )

    raw = response.choices[0].message.content.strip()
    if raw.startswith("```"):
        raw = raw.split("```")[1]
        if raw.startswith("json"):
            raw = raw[4:]
    return json.loads(raw)