from pydantic import BaseModel
from typing import Optional, List

class ServiceLine(BaseModel):
    date_of_service_from: Optional[str] = None
    date_of_service_to: Optional[str] = None
    place_of_service: Optional[str] = None
    emg: Optional[str] = None
    procedure_code: Optional[str] = None
    modifier: Optional[str] = None
    diagnosis_pointer: Optional[str] = None
    charges: Optional[float] = None
    days_or_units: Optional[int] = None
    epsdt_family_plan: Optional[str] = None
    rendering_provider_id: Optional[str] = None
    rendering_provider_npi: Optional[str] = None

class CMS1500(BaseModel):
    # Box 1
    insurance_type: Optional[str] = None
    # Box 1a
    insured_id_number: Optional[str] = None
    # Box 2
    patient_name: Optional[str] = None
    # Box 3
    patient_dob: Optional[str] = None
    patient_sex: Optional[str] = None
    # Box 4
    insured_name: Optional[str] = None
    # Box 5
    patient_address: Optional[str] = None
    patient_city: Optional[str] = None
    patient_state: Optional[str] = None
    patient_zip: Optional[str] = None
    patient_phone: Optional[str] = None
    # Box 6
    patient_relationship_to_insured: Optional[str] = None
    # Box 7
    insured_address: Optional[str] = None
    insured_city: Optional[str] = None
    insured_state: Optional[str] = None
    insured_zip: Optional[str] = None
    insured_phone: Optional[str] = None
    # Box 8
    reserved_for_nucc_use: Optional[str] = None
    # Box 9
    other_insured_name: Optional[str] = None
    # Box 9a
    other_insured_policy_or_group_number: Optional[str] = None
    # Box 9d
    other_insurance_plan_name: Optional[str] = None
    # Box 10a
    condition_related_to_employment: Optional[str] = None
    # Box 10b
    condition_related_to_auto_accident: Optional[str] = None
    auto_accident_state: Optional[str] = None
    # Box 10c
    condition_related_to_other_accident: Optional[str] = None
    # Box 10d
    claim_codes: Optional[str] = None
    # Box 11
    insured_policy_group_or_feca_number: Optional[str] = None
    # Box 11a
    insured_dob: Optional[str] = None
    insured_sex: Optional[str] = None
    # Box 11b
    other_claim_id: Optional[str] = None
    # Box 11c
    insurance_plan_name: Optional[str] = None
    # Box 11d
    another_health_benefit_plan: Optional[str] = None
    # Box 12
    patient_signature: Optional[str] = None
    patient_signature_date: Optional[str] = None
    # Box 13
    insured_signature: Optional[str] = None
    # Box 14
    illness_injury_pregnancy_date: Optional[str] = None
    date_qualifier: Optional[str] = None
    # Box 15
    other_date: Optional[str] = None
    other_date_qualifier: Optional[str] = None
    # Box 16
    unable_to_work_from_date: Optional[str] = None
    unable_to_work_to_date: Optional[str] = None
    # Box 17
    referring_provider_name: Optional[str] = None
    referring_provider_qualifier: Optional[str] = None
    # Box 17a
    other_id_number: Optional[str] = None
    # Box 17b
    referring_provider_npi: Optional[str] = None
    # Box 18
    hospitalization_from_date: Optional[str] = None
    hospitalization_to_date: Optional[str] = None
    # Box 19
    additional_claim_information: Optional[str] = None
    # Box 20
    outside_lab: Optional[str] = None
    outside_lab_charges: Optional[float] = None
    # Box 21
    icd_indicator: Optional[str] = None
    diagnosis_codes: Optional[List[str]] = None
    # Box 22
    resubmission_code: Optional[str] = None
    original_ref_number: Optional[str] = None
    # Box 23
    prior_authorization_number: Optional[str] = None
    # Box 24
    service_lines: Optional[List[ServiceLine]] = None
    # Box 25
    federal_tax_id: Optional[str] = None
    tax_id_type: Optional[str] = None
    # Box 26
    patient_account_number: Optional[str] = None
    # Box 27
    accept_assignment: Optional[str] = None
    # Box 28
    total_charge: Optional[float] = None
    # Box 29
    amount_paid: Optional[float] = None
    # Box 30
    reserved_for_nucc_use_30: Optional[str] = None
    # Box 31
    signature_of_physician: Optional[str] = None
    signature_date: Optional[str] = None
    # Box 32
    service_facility_name: Optional[str] = None
    service_facility_address: Optional[str] = None
    service_facility_city_state_zip: Optional[str] = None
    service_facility_npi: Optional[str] = None
    service_facility_other_id: Optional[str] = None
    # Box 33
    billing_provider_phone: Optional[str] = None
    billing_provider_name: Optional[str] = None
    billing_provider_address: Optional[str] = None
    billing_provider_city_state_zip: Optional[str] = None
    billing_provider_npi: Optional[str] = None
    billing_provider_other_id: Optional[str] = None

def validate(data: dict) -> CMS1500:
    return CMS1500(**data)